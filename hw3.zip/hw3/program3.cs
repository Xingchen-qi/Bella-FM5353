using System;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace MCOptions
{
    public abstract class Opt
    {
        public double S0 { get; set; }
        public double K { get; set; }
        public double r { get; set; }
        public double sig { get; set; }
        public double T { get; set; }
        public int N { get; set; }

        public abstract double Pay(double[] path, double kAlt = double.NaN);
        public virtual bool PathDep => false;
    }

    public class EuroOpt : Opt
    {
        public bool IsCall { get; set; } = true;
        public override double Pay(double[] path, double _ = double.NaN)
        {
            double ST = path[^1];
            return IsCall ? Math.Max(ST - K, 0.0) : Math.Max(K - ST, 0.0);
        }
    }

    public class AsianOpt : Opt
    {
        public bool IsCall { get; set; } = true;
        public override bool PathDep => true;
        public override double Pay(double[] path, double _ = double.NaN)
        {
            double avg = path.Average();
            return IsCall ? Math.Max(avg - K, 0.0) : Math.Max(K - avg, 0.0);
        }
    }

    public class DigitOpt : Opt
    {
        public bool IsCall { get; set; } = true;
        public double Payout { get; set; } = 1.0;
        public override double Pay(double[] path, double _ = double.NaN)
        {
            double ST = path[^1];
            bool itm = IsCall ? (ST > K) : (ST < K);
            return itm ? Payout : 0.0;
        }
    }

    public enum KnockT { DO, UO, DI, UI }

    public class BarrOpt : Opt
    {
        public bool IsCall { get; set; } = true;
        public double B { get; set; }
        public KnockT Knock { get; set; } = KnockT.DO;
        public override bool PathDep => true;

        public override double Pay(double[] path, double _ = double.NaN)
        {
            double mx = path.Max();
            double mn = path.Min();

            bool hit = false;
            switch (Knock)
            {
                case KnockT.UO:
                case KnockT.UI:
                    hit = mx >= B; break;
                case KnockT.DO:
                case KnockT.DI:
                    hit = mn <= B; break;
            }

            double euro = new EuroOpt { K = this.K, S0 = this.S0, r = this.r, sig = this.sig, T = this.T, N = this.N, IsCall = this.IsCall }.Pay(path);

            bool isOut = (Knock == KnockT.UO || Knock == KnockT.DO);
            if (isOut) return hit ? 0.0 : euro;
            else return hit ? euro : 0.0;
        }
    }

    public class LookOpt : Opt
    {
        public bool IsCall { get; set; } = true;
        public override bool PathDep => true;
        public override double Pay(double[] path, double _ = double.NaN)
        {
            double mx = path.Max();
            double mn = path.Min();
            return IsCall ? Math.Max(mx - K, 0.0) : Math.Max(K - mn, 0.0);
        }
    }

    public class RangeOpt : Opt
    {
        public override bool PathDep => true;
        public override double Pay(double[] path, double _ = double.NaN)
        {
            return path.Max() - path.Min();
        }
    }

    public class SimRes
    {
        public double Price { get; set; }
        public double StdErr { get; set; }
        public double Delta { get; set; }
        public double Gamma { get; set; }
        public double Vega { get; set; }
        public double Theta { get; set; }
        public double Rho { get; set; }
    }

    public class MCEngine
    {
        readonly bool anti;
        readonly bool cv;
        readonly bool mt;
        readonly int nTh;

        public MCEngine(bool a, bool c, bool m)
        {
            anti = a;
            cv = c;
            mt = m;
            nTh = m ? Math.Max(1, Environment.ProcessorCount) : 1;
        }

        public SimRes Run(Opt opt, int sims, double bump = 1e-3)
        {
            if (!mt) return RunPart(opt, sims, seed: 42, bump);

            int per = sims / nTh;
            int rem = sims % nTh;
            var tasks = new List<Task<SimRes>>();
            int seed0 = 1337;

            for (int t = 0; t < nTh; t++)
            {
                int loc = per + (t < rem ? 1 : 0);
                int seed = seed0 + t * 7919;
                if (loc == 0) continue;
                tasks.Add(Task.Run(() => RunPart(opt, loc, seed, bump)));
            }

            Task.WaitAll(tasks.ToArray());

            double disc = Math.Exp(-opt.r * opt.T);
            double totPay = tasks.Sum(x => x.Result.Price);
            double totSims = tasks.Count;


            double mean = totPay / totSims;

            var all = tasks.Select(x => x.Result).ToList();
            double var = PoolVar(all);
            double se = Math.Sqrt(var / totSims);

            double d = all.Average(x => x.Delta);
            double g = all.Average(x => x.Gamma);
            double v = all.Average(x => x.Vega);
            double th = all.Average(x => x.Theta);
            double rh = all.Average(x => x.Rho);

            return new SimRes { Price = mean, StdErr = se, Delta = d, Gamma = g, Vega = v, Theta = th, Rho = rh };
        }

        private SimRes RunPart(Opt opt, int sims, int seed, double bump)
        {
            var rng = new Random(seed);
            int N = opt.N;
            double dt = opt.T / N;
            double a1 = (opt.r - 0.5 * opt.sig * opt.sig) * dt;
            double a2 = opt.sig * Math.Sqrt(dt);
            double grow = Math.Exp(opt.r * dt);
            double disc = Math.Exp(-opt.r * opt.T);

            double sumP = 0.0, sumP2 = 0.0;
            double dSum = 0.0, gSum = 0.0, vSum = 0.0, tSum = 0.0, rSum = 0.0;

            double[] path = new double[N + 1];
            double[] pathA = new double[N + 1];
            double[] z = new double[N];

            for (int j = 0; j < sims; j++)
            {
                path[0] = opt.S0;
                if (anti) pathA[0] = opt.S0;

                for (int i = 1; i <= N; i++)
                {
                    double zi = BoxMuller(rng);
                    z[i - 1] = zi;
                    path[i] = path[i - 1] * Math.Exp(a1 + a2 * zi);
                    if (anti) pathA[i] = pathA[i - 1] * Math.Exp(a1 - a2 * zi);
                }

                double p = opt.Pay(path);
                double pA = 0.0;
                if (anti) pA = opt.Pay(pathA);

                double cvSum = 0.0, cvA = 0.0;
                if (cv)
                {
                    double s = opt.S0, sA = opt.S0;
                    for (int i = 1; i <= N; i++)
                    {
                        double tau = (i - 1) * dt;
                        double zi = z[i - 1];
                        double st = s * Math.Exp(a1 + a2 * zi);
                        double dBS = BSDelta(s, opt.K, opt.r, opt.sig, opt.T - tau);
                        cvSum += dBS * (st - s * grow);
                        s = st;

                        if (anti)
                        {
                            double stA = sA * Math.Exp(a1 - a2 * zi);
                            double dA = BSDelta(sA, opt.K, opt.r, opt.sig, opt.T - tau);
                            cvA += dA * (stA - sA * grow);
                            sA = stA;
                        }
                    }
                }

                double pay = p;
                if (cv) pay -= cvSum;
                if (anti)
                {
                    double pAlt = pA;
                    if (cv) pAlt -= cvA;
                    pay = 0.5 * (pay + pAlt);
                }

                double discP = disc * pay;
                sumP += discP;
                sumP2 += discP * discP;

                double dS = Math.Max(1e-6, bump * opt.S0);
                double pUp = PriceBump(opt, z, +1, dS);
                double pDn = PriceBump(opt, z, -1, dS);
                double delta = (pUp - pDn) / (2 * dS);
                double gamma = (pUp - 2 * (discP) + pDn) / (dS * dS);

                double dSig = Math.Max(1e-6, bump);
                double pSU = PriceSig(opt, z, opt.sig + dSig);
                double pSD = PriceSig(opt, z, Math.Max(1e-8, opt.sig - dSig));
                double vega = (pSU - pSD) / (2 * dSig);

                double dR = Math.Max(1e-6, bump);
                double pRU = PriceR(opt, z, opt.r + dR);
                double pRD = PriceR(opt, z, opt.r - dR);
                double rho = (pRU - pRD) / (2 * dR);

                double dT = Math.Max(1e-6, bump) * opt.T;
                double pTU = PriceT(opt, z, Math.Max(1e-8, opt.T + dT));
                double pTD = PriceT(opt, z, Math.Max(1e-8, opt.T - dT));
                double theta = (pTU - pTD) / (2 * dT);

                dSum += delta; gSum += gamma; vSum += vega; tSum += theta; rSum += rho;
            }

            double mean = sumP / sims;
            double var = Math.Max(0.0, sumP2 / sims - mean * mean);
            double se = Math.Sqrt(var / sims);

            return new SimRes
            {
                Price = mean,
                StdErr = se,
                Delta = dSum / sims,
                Gamma = gSum / sims,
                Vega = vSum / sims,
                Theta = tSum / sims,
                Rho = rSum / sims
            };
        }

        private static double PoolVar(List<SimRes> xs)
        {
            if (xs.Count == 0) return 0.0;
            double meanVar = xs.Average(x => x.StdErr * x.StdErr);
            return meanVar;

        }

        private static double BSDelta(double S, double K, double r, double sig, double tau)
        {
            if (tau <= 0) return S > K ? 1.0 : 0.0;
            double d1 = (Math.Log(S / K) + (r + 0.5 * sig * sig) * tau) / (sig * Math.Sqrt(tau));
            return Phi(d1);
        }

        private static double PriceBump(Opt opt, double[] z, int dir, double dS)
        {
            int N = opt.N;
            double T = opt.T;
            double dt = T / N;
            double a1 = (opt.r - 0.5 * opt.sig * opt.sig) * dt;
            double a2 = opt.sig * Math.Sqrt(dt);
            double disc = Math.Exp(-opt.r * T);
            double[] path = new double[N + 1];
            double S0b = opt.S0 + dir * dS;
            path[0] = S0b;
            for (int i = 1; i <= N; i++)
                path[i] = path[i - 1] * Math.Exp(a1 + a2 * z[i - 1]);
            double p = opt.Pay(path);
            return disc * p;
        }

        private static double PriceSig(Opt opt, double[] z, double sigN)
        {
            int N = opt.N;
            double dt = opt.T / N;
            double a1 = (opt.r - 0.5 * sigN * sigN) * dt;
            double a2 = sigN * Math.Sqrt(dt);
            double disc = Math.Exp(-opt.r * opt.T);
            double[] path = new double[N + 1];
            path[0] = opt.S0;
            for (int i = 1; i <= N; i++)
                path[i] = path[i - 1] * Math.Exp(a1 + a2 * z[i - 1]);
            return disc * opt.Pay(path);
        }

        private static double PriceR(Opt opt, double[] z, double rN)
        {
            int N = opt.N;
            double dt = opt.T / N;
            double a1 = (rN - 0.5 * opt.sig * opt.sig) * dt;
            double a2 = opt.sig * Math.Sqrt(dt);
            double disc = Math.Exp(-rN * opt.T);
            double[] path = new double[N + 1];
            path[0] = opt.S0;
            for (int i = 1; i <= N; i++)
                path[i] = path[i - 1] * Math.Exp(a1 + a2 * z[i - 1]);
            return disc * opt.Pay(path);
        }

        private static double PriceT(Opt opt, double[] z, double TN)
        {
            int N = opt.N;
            double dt = TN / N;
            double a1 = (opt.r - 0.5 * opt.sig * opt.sig) * dt;
            double a2 = opt.sig * Math.Sqrt(dt);
            double disc = Math.Exp(-opt.r * TN);
            double[] path = new double[N + 1];
            path[0] = opt.S0;
            for (int i = 1; i <= N; i++)
                path[i] = path[i - 1] * Math.Exp(a1 + a2 * z[i - 1]);
            return disc * opt.Pay(path);
        }

        private double BoxMuller(Random rand)
        {
            double u1 = 1.0 - rand.NextDouble();
            double u2 = 1.0 - rand.NextDouble();
            return Math.Sqrt(-2.0 * Math.Log(u1)) * Math.Cos(2.0 * Math.PI * u2);
        }

        private double CumDensity(double z)
        {
            double p = 0.3275911;
            double a1 = 0.254829592;
            double a2 = -0.284496736;
            double a3 = 1.421413741;
            double a4 = -1.453152027;
            double a5 = 1.061405429;

            int sign = z < 0.0 ? -1 : 1;
            double x = Math.Abs(z) / Math.Sqrt(2.0);
            double t = 1.0 / (1.0 + p * x);
            double erf = 1.0 - (((((a5 * t + a4) * t) + a3)
                * t + a2) * t + a1) * t * Math.Exp(-x * x);
            return 0.5 * (1.0 + sign * erf);
        }
    }

    public static class ResExt
    {
        public static int ResultCnt(this SimRes _) => 0;
    }

    public class Program
    {
        public static void Main()
        {
            Console.WriteLine("Monte Carlo Option Pricing Simulator");

            double S0 = ReadD("Initial stock price: ");
            double K = ReadD("Strike price (ignored by Range): ");
            double r = ReadD("Risk-free rate: ");
            double sig = ReadD("Volatility: ");
            double T = ReadD("Time to maturity in years: ");
            int N = ReadI("Number of steps: ");
            int sims = ReadI("Number of simulations: ");

            bool anti = ReadYes("Use Antithetic Variates? (yes/no): ");
            bool cv = ReadYes("Use Delta Control Variate? (yes/no): ");
            bool mt = ReadYes("Use multithreading? (yes/no): ");

            Console.Write("Enter option type (euro/asian/digital/barrier/lookback/range): ");
            string type = Console.ReadLine().Trim().ToLower();

            Opt opt = type switch
            {
                "euro" => new EuroOpt { IsCall = ReadYes("Call? (yes/no): ") },
                "asian" => new AsianOpt { IsCall = ReadYes("Call? (yes/no): ") },
                "digital" => new DigitOpt { IsCall = ReadYes("Call? (yes/no): "), Payout = ReadD("Digital payout: ") },
                "barrier" => MakeBarr(),
                "lookback" => new LookOpt { IsCall = ReadYes("Call (fixed strike)? (yes/no): ") },
                "range" => new RangeOpt { },
                _ => new EuroOpt { IsCall = true }
            };

            opt.S0 = S0; opt.K = K; opt.r = r; opt.sig = sig; opt.T = T; opt.N = N;

            var eng = new MCEngine(anti, cv, mt);
            var res = eng.Run(opt, sims);

            Console.WriteLine($"Price: {res.Price:F6}");
        }

        private static BarrOpt MakeBarr()
        {
            var bo = new BarrOpt { IsCall = ReadYes("Call? (yes/no): ") };
            bo.B = ReadD("Barrier level B: ");
            Console.Write("Knock type (do/uo/di/ui): ");
            string k = Console.ReadLine()?.Trim().ToLower() ?? "do";
            bo.Knock = k switch
            {
                "do" => KnockT.DO,
                "uo" => KnockT.UO,
                "di" => KnockT.DI,
                "ui" => KnockT.UI,
                _ => KnockT.DO
            };
            return bo;
        }

        private static double ReadD(string msg)
        {
            Console.Write(msg);
            return double.Parse(Console.ReadLine() ?? "0");
        }

        private static int ReadI(string msg)
        {
            Console.Write(msg);
            return int.Parse(Console.ReadLine() ?? "0");
        }

        private static bool ReadYes(string msg)
        {
            Console.Write(msg);
            return (Console.ReadLine()?.Trim().ToLower() ?? "no") == "yes";
        }
    }
}

