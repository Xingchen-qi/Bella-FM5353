using System;

namespace MCOptions.Api.Models
{
    public class Trade
    {
        public int Id { get; set; }
        public int DerivativeId { get; set; }
        public Derivative? Derivative { get; set; }
        public int Quantity { get; set; }
        public DateTime TradeDate { get; set; } = DateTime.UtcNow;
    }
}
