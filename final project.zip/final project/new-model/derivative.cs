using System.Collections.Generic;

namespace MCOptions.Api.Models
{
    public abstract class Derivative
    {
        public int Id { get; set; }
        public int UnderlyingId { get; set; }
        public Underlying? Underlying { get; set; }
        public double K { get; set; }
        public double T { get; set; }
        public int N { get; set; }
        public bool IsCall { get; set; }
        public List<Trade> Trades { get; set; } = new();
    }

    public class EuroDerivative : Derivative
    {
    }

    public class AsianDerivative : Derivative
    {
    }

    public class DigitalDerivative : Derivative
    {
        public double Payout { get; set; } = 1.0;
    }

    public class BarrierDerivative : Derivative
    {
        public double B { get; set; }
        public string Knock { get; set; } = "do";
    }

    public class LookbackDerivative : Derivative
    {
    }

    public class RangeDerivative : Derivative
    {
    }
}
