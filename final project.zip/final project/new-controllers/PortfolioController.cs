using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MCOptions.Api.Data;
using MCOptions.Api.Models;
using MCOptions;

namespace MCOptions.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PortfolioController : ControllerBase
    {
        private readonly AppDbContext _db;

        public PortfolioController(AppDbContext db)
        {
            _db = db;
        }
        public class PortfolioEvalRequest
        {
            public int Sims { get; set; } = 10000;
            public bool Antithetic { get; set; } = false;
            public bool ControlVariate { get; set; } = false;
            public bool Multithreading { get; set; } = false;
            public double Bump { get; set; } = 1e-3;
        }

        public class PortfolioEvalResult
        {
            public double TotalMarketValue { get; set; }
            public double TotalDelta { get; set; }
            public double TotalGamma { get; set; }
            public double TotalVega { get; set; }
            public double TotalTheta { get; set; }
            public double TotalRho { get; set; }
        }

        [HttpPost("evaluate")]
        public async Task<ActionResult<PortfolioEvalResult>> Evaluate(PortfolioEvalRequest req)
        {
            var trades = await _db.Trades
                .Include(t => t.Derivative)
                .ThenInclude(d => d!.Underlying)
                .ToListAsync();

            if (!trades.Any())
                return Ok(new PortfolioEvalResult());

            var engine = new MCEngine(
                a: req.Antithetic,
                c: req.ControlVariate,
                m: req.Multithreading
            );

            double totalV = 0.0;
            double totalDelta = 0.0;
            double totalGamma = 0.0;
            double totalVega = 0.0;
            double totalTheta = 0.0;
            double totalRho = 0.0;

            foreach (var t in trades)
            {
                var d = t.Derivative!;
                var u = d.Underlying!;

                Opt opt = BuildOptFromDerivative(d, u);

                var res = engine.Run(opt, req.Sims, req.Bump);

                double q = t.Quantity;
                totalV+= res.Price * q;
                totalDelta+= res.Delta * q;
                totalGamma+= res.Gamma * q;
                totalVega+= res.Vega  * q;
                totalTheta += res.Theta * q;
                totalRho += res.Rho   * q;
            }

            var outRes = new PortfolioEvalResult
            {
                TotalMarketValue = totalV,
                TotalDelta = totalDelta,
                TotalGamma = totalGamma,
                TotalVega = totalVega,
                TotalTheta = totalTheta,
                TotalRho = totalRho
            };

            return Ok(outRes);
        }

        private static Opt BuildOptFromDerivative(Derivative d, Underlying u)
        {
            Opt opt;

            if (d is EuroDerivative)
            {
                opt = new EuroOpt { IsCall = d.IsCall };
            }
            else if (d is AsianDerivative)
            {
                opt = new AsianOpt { IsCall = d.IsCall };
            }
            else if (d is DigitalDerivative dig)
            {
                opt = new DigitOpt { IsCall = d.IsCall, Payout = dig.Payout };
            }
            else if (d is BarrierDerivative b)
            {
                var bo = new BarrOpt
                {
                    IsCall = d.IsCall,
                    B = b.B
                };

                string k = (b.Knock ?? "do").Trim().ToLower();
                bo.Knock = k switch
                {
                    "do" => KnockT.DO,
                    "uo" => KnockT.UO,
                    "di" => KnockT.DI,
                    "ui" => KnockT.UI,
                    _ => KnockT.DO
                };

                opt = bo;
            }
            else if (d is LookbackDerivative)
            {
                opt = new LookOpt { IsCall = d.IsCall };
            }
            else if (d is RangeDerivative)
            {
                opt = new RangeOpt();
            }
            else
            {
                opt = new EuroOpt { IsCall = true };
            }

            opt.S0 = u.Spot;
            opt.K = d.K;
            opt.r = u.Rate;
            opt.sig = u.Vol;
            opt.T = d.T;
            opt.N = d.N;
            return opt;
        }
    }
}
