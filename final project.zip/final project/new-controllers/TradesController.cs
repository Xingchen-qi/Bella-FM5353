using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MCOptions.Api.Data;
using MCOptions.Api.Models;

namespace MCOptions.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TradesController : ControllerBase
    {
        private readonly AppDbContext _db;

        public TradesController(AppDbContext db)
        {
            _db = db;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Trade>>> GetAll()
        {
            return await _db.Trades
                .Include(t => t.Derivative)
                .ThenInclude(d => d!.Underlying)
                .ToListAsync();
        }

        [HttpGet("{id:int}")]
        public async Task<ActionResult<Trade>> GetById(int id)
        {
            var t = await _db.Trades
                .Include(x => x.Derivative)
                .ThenInclude(d => d!.Underlying)
                .FirstOrDefaultAsync(x => x.Id == id);

            if (t == null) return NotFound();
            return t;
        }

        [HttpPost]
        public async Task<ActionResult<Trade>> Create(Trade trade)
        {
            _db.Trades.Add(trade);
            await _db.SaveChangesAsync();
            return CreatedAtAction(nameof(GetById), new { id = trade.Id }, trade);
        }

        [HttpPut("{id:int}")]
        public async Task<IActionResult> Update(int id, Trade trade)
        {
            if (id != trade.Id) return BadRequest();

            _db.Entry(trade).State = EntityState.Modified;
            await _db.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            var t = await _db.Trades.FindAsync(id);
            if (t == null) return NotFound();

            _db.Trades.Remove(t);
            await _db.SaveChangesAsync();
            return NoContent();
        }
    }
}
