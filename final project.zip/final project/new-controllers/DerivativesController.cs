using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MCOptions.Api.Data;
using MCOptions.Api.Models;

namespace MCOptions.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class DerivativesController : ControllerBase
    {
        private readonly AppDbContext _db;

        public DerivativesController(AppDbContext db)
        {
            _db = db;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Derivative>>> GetAll()
        {
            return await _db.Derivatives
                .Include(d => d.Underlying)
                .ToListAsync();
        }

        [HttpGet("{id:int}")]
        public async Task<ActionResult<Derivative>> GetById(int id)
        {
            var d = await _db.Derivatives
                .Include(x => x.Underlying)
                .FirstOrDefaultAsync(x => x.Id == id);

            if (d == null) return NotFound();
            return d;
        }

        [HttpPost("euro")]
        public async Task<ActionResult<EuroDerivative>> CreateEuro(EuroDerivative d)
        {
            _db.EuroDerivatives.Add(d);
            await _db.SaveChangesAsync();
            return CreatedAtAction(nameof(GetById), new { id = d.Id }, d);
        }

        [HttpPost("asian")]
        public async Task<ActionResult<AsianDerivative>> CreateAsian(AsianDerivative d)
        {
            _db.AsianDerivatives.Add(d);
            await _db.SaveChangesAsync();
            return CreatedAtAction(nameof(GetById), new { id = d.Id }, d);
        }

        [HttpPost("digital")]
        public async Task<ActionResult<DigitalDerivative>> CreateDigital(DigitalDerivative d)
        {
            _db.DigitalDerivatives.Add(d);
            await _db.SaveChangesAsync();
            return CreatedAtAction(nameof(GetById), new { id = d.Id }, d);
        }

        [HttpPost("barrier")]
        public async Task<ActionResult<BarrierDerivative>> CreateBarrier(BarrierDerivative d)
        {
            _db.BarrierDerivatives.Add(d);
            await _db.SaveChangesAsync();
            return CreatedAtAction(nameof(GetById), new { id = d.Id }, d);
        }

        [HttpPost("lookback")]
        public async Task<ActionResult<LookbackDerivative>> CreateLookback(LookbackDerivative d)
        {
            _db.LookbackDerivatives.Add(d);
            await _db.SaveChangesAsync();
            return CreatedAtAction(nameof(GetById), new { id = d.Id }, d);
        }

        [HttpPost("range")]
        public async Task<ActionResult<RangeDerivative>> CreateRange(RangeDerivative d)
        {
            _db.RangeDerivatives.Add(d);
            await _db.SaveChangesAsync();
            return CreatedAtAction(nameof(GetById), new { id = d.Id }, d);
        }

        [HttpPut("{id:int}")]
        public async Task<IActionResult> Update(int id, Derivative d)
        {
            if (id != d.Id) return BadRequest();
            _db.Entry(d).State = EntityState.Modified;
            await _db.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            var d = await _db.Derivatives.FindAsync(id);
            if (d == null) return NotFound();

            _db.Derivatives.Remove(d);
            await _db.SaveChangesAsync();
            return NoContent();
        }
    }
}
