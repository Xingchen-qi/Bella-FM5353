namespace MCOptions.Api.DataTransfer
{
    public class EuroD : BaseOptD
    {
    }
}
