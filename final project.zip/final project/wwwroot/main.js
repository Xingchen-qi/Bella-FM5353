console.log("JavaScript loaded!");

let runButton = document.getElementById("run-btn");
console.log("Button loaded:", runButton);

runButton.addEventListener("click", async function () {
    console.log("Run button was clicked!");
    const statusElem = document.getElementById("status");
    const resultElem = document.getElementById("result");
    const greeksElem = document.getElementById("greeks");

    statusElem.textContent = "Running Monte Carlo…";
    resultElem.textContent = "";
    greeksElem.textContent = "";

    const optType = document.getElementById("input-opt").value;
    let url = `/api/pricingc/${optType}`;


    const isCall = document.getElementById("input-isCall").value === "true";
    const S0 = parseFloat(document.getElementById("input-S0").value);
    const K = parseFloat(document.getElementById("input-K0").value);
    const r = parseFloat(document.getElementById("input-r").value);
    const sig= parseFloat(document.getElementById("input-sig").value);
    const T= parseFloat(document.getElementById("input-T").value);
    const N= parseInt(document.getElementById("input-N").value);
    const Sims = parseInt(document.getElementById("input-Sims").value);
    const useAntithetic = document.getElementById("eng-antithetic").checked;
    const useCV= document.getElementById("eng-cv").checked;
    const useMT= document.getElementById("eng-mt").checked;

    const payload = {
        type: optType,
        S0: S0,
        K: K,
        r: r,
        sig: sig,
        T: T,
        N: N,
        Sims: Sims,
        IsCall: isCall,
        Bump: 0.01,
        Engine: {
            Antithetic: useAntithetic,
            ControlVariate: useCV,
            Multithreading: useMT
        }
    };

    console.log("Calling URL:", url);
    console.log("Payload being sent:", payload);

    try {
        let resp = await fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });

        if (!resp.ok) {
            throw new Error("API returned status: " + resp.status);
        }

        let data = await resp.json();
        console.log("API returned:", data);

        resultElem.textContent =
            `Price = ${data.price}, StdErr = ${data.stdErr}`;

        function fmt(x) {
            return (typeof x === "number") ? x : "n/a";
        }

        greeksElem.textContent =
            `Greeks: ` +
            `Delta = ${fmt(data.delta)}, ` +
            `Gamma = ${fmt(data.gamma)}, ` +
            `Vega = ${fmt(data.vega)}, ` +
            `Theta = ${fmt(data.theta)}, ` +
            `Rho = ${fmt(data.rho)}`;

        statusElem.textContent = "Simulation Complete!";
    }
    catch (err) {
        console.error("API call failed:", err);
        resultElem.textContent = "Error calling API.";
        greeksElem.textContent = "";
        statusElem.textContent = "API Error";
    }
});
