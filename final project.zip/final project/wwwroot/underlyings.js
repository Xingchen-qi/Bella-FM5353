const api = "/api/underlyings";

async function loadUnderlyings() {
    const res = await fetch(api);
    const data = await res.json();

    const tbody = document.getElementById("list");
    tbody.innerHTML = "";

    data.forEach(u => {
        const tr = document.createElement("tr");

        tr.innerHTML = `
            <td>${u.id}</td>
            <td>${u.symbol}</td>
            <td>${u.spot}</td>
            <td>${u.rate}</td>
            <td>${u.vol}</td>
            <td><button onclick="deleteUnderlying(${u.id})">Delete</button></td>
        `;

        tbody.appendChild(tr);
    });
}

async function createUnderlying() {
    const body = {
        symbol: document.getElementById("symbol").value,
        spot: parseFloat(document.getElementById("spot").value),
        rate: parseFloat(document.getElementById("rate").value),
        vol: parseFloat(document.getElementById("vol").value)
    };

    await fetch(api, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
    });

    loadUnderlyings();
}

async function deleteUnderlying(id) {
    await fetch(`${api}/${id}`, { method: "DELETE" });
    loadUnderlyings();
}

document.getElementById("create-btn").addEventListener("click", createUnderlying);
loadUnderlyings();
