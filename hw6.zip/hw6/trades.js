const apiTrades = "http://localhost:5100/api/trades";

async function loadTrades() {
    const res = await fetch(apiTrades);
    const data = await res.json();

    const tbody = document.getElementById("list");
    tbody.innerHTML = "";

    data.forEach(t => {
        const tr = document.createElement("tr");

        tr.innerHTML = `
            <td>${t.id}</td>
            <td>${t.derivativeId}</td>
            <td>${t.derivative?.underlying?.symbol ?? ""}</td>
            <td>${t.quantity}</td>
            <td>${t.tradeDate.substring(0, 10)}</td>
        `;

        tbody.appendChild(tr);
    });
}

async function createTrade() {
    const body = {
        derivativeId: parseInt(document.getElementById("dId").value),
        quantity: parseInt(document.getElementById("qty").value)
    };

    await fetch(apiTrades, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
    });

    loadTrades();
}

document.getElementById("create-btn").addEventListener("click", createTrade);
loadTrades();
