namespace MCOptions.Api.DataTransfer
{
    public class BarrierD : BaseOptD
    {
        public double B { get; set; }      // Barrier level
        public string? Knock { get; set; } // "do", "di", "uo", or "ui"
    }
}

