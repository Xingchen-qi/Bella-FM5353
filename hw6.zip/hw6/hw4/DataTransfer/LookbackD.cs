namespace MCOptions.Api.DataTransfer
{
    public class LookbackD : BaseOptD
    {
    }
}
