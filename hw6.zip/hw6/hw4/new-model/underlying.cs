using System.Collections.Generic;

namespace MCOptions.Api.Models
{
    public class Underlying
    {
        public int Id { get; set; }
        public string Symbol { get; set; } = string.Empty;
        public double Spot { get; set; }
        public double Rate { get; set; }
        public double Vol { get; set; }
        public List<Derivative> Derivatives { get; set; } = new();
    }
}
