using Microsoft.EntityFrameworkCore;
using MCOptions.Api.Models;

namespace MCOptions.Api.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {
        }

        public DbSet<Underlying> Underlyings => Set<Underlying>();
        public DbSet<Derivative> Derivatives => Set<Derivative>();
        public DbSet<EuroDerivative> EuroDerivatives => Set<EuroDerivative>();
        public DbSet<AsianDerivative> AsianDerivatives => Set<AsianDerivative>();
        public DbSet<DigitalDerivative> DigitalDerivatives => Set<DigitalDerivative>();
        public DbSet<BarrierDerivative> BarrierDerivatives => Set<BarrierDerivative>();
        public DbSet<LookbackDerivative> LookbackDerivatives => Set<LookbackDerivative>();
        public DbSet<RangeDerivative> RangeDerivatives => Set<RangeDerivative>();

        public DbSet<Trade> Trades => Set<Trade>();

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Derivative>()
                .HasDiscriminator<string>("DerivType")
                .HasValue<EuroDerivative>("euro")
                .HasValue<AsianDerivative>("asian")
                .HasValue<DigitalDerivative>("digital")
                .HasValue<BarrierDerivative>("barrier")
                .HasValue<LookbackDerivative>("lookback")
                .HasValue<RangeDerivative>("range");

            modelBuilder.Entity<Underlying>()
                .HasMany(u => u.Derivatives)
                .WithOne(d => d.Underlying)
                .HasForeignKey(d => d.UnderlyingId);

            modelBuilder.Entity<Derivative>()
                .HasMany(d => d.Trades)
                .WithOne(t => t.Derivative)
                .HasForeignKey(t => t.DerivativeId);
        }
    }
}
