using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MCOptions.Api.Data;
using MCOptions.Api.Models;

namespace MCOptions.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UnderlyingsController : ControllerBase
    {
        private readonly AppDbContext _db;

        public UnderlyingsController(AppDbContext db)
        {
            _db = db;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Underlying>>> GetAll()
        {
            return await _db.Underlyings.ToListAsync();
        }

        [HttpGet("{id:int}")]
        public async Task<ActionResult<Underlying>> GetById(int id)
        {
            var u = await _db.Underlyings.FindAsync(id);
            if (u == null) return NotFound();
            return u;
        }

        [HttpPost]
        public async Task<ActionResult<Underlying>> Create(Underlying u)
        {
            _db.Underlyings.Add(u);
            await _db.SaveChangesAsync();
            return CreatedAtAction(nameof(GetById), new { id = u.Id }, u);
        }

        [HttpPut("{id:int}")]
        public async Task<IActionResult> Update(int id, Underlying u)
        {
            if (id != u.Id) return BadRequest();

            _db.Entry(u).State = EntityState.Modified;
            await _db.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            var u = await _db.Underlyings.FindAsync(id);
            if (u == null) return NotFound();

            _db.Underlyings.Remove(u);
            await _db.SaveChangesAsync();
            return NoContent();
        }
    }
}
