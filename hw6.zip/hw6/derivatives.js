const api = "http://localhost:5100/api/derivatives";

async function loadDerivatives() {
    const res = await fetch(api);
    const data = await res.json();

    const tbody = document.getElementById("list");
    tbody.innerHTML = "";

    data.forEach(d => {
        const tr = document.createElement("tr");

        tr.innerHTML = `
            <td>${d.id}</td>
            <td>${d.underlyingId}</td>
            <td>${d.k}</td>
            <td>${d.t}</td>
            <td>${d.n}</td>
            <td>${d.isCall}</td>
        `;

        tbody.appendChild(tr);
    });
}

async function createDerivative(type) {
    const body = {
        underlyingId: parseInt(document.getElementById("uId").value),
        k: parseFloat(document.getElementById("K").value),
        t: parseFloat(document.getElementById("T").value),
        n: parseInt(document.getElementById("N").value),
        isCall: document.getElementById("isCall").checked
    };

    if (type === "digital") {
        body.payout = parseFloat(document.getElementById("payout").value);
    }

    if (type === "barrier") {
        body.b = parseFloat(document.getElementById("barrier").value);
        body.knock = document.getElementById("knock").value;
    }

    await fetch(`${api}/${type}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
    });

    loadDerivatives();
}

loadDerivatives();
