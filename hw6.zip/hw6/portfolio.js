const apiTrades = "http://localhost:5100/api/trades";
const apiEval = "http://localhost:5100/api/portfolio/evaluate";

async function loadTrades() {
    const res = await fetch(apiTrades);
    const data = await res.json();

    const tbody = document.getElementById("trades");
    tbody.innerHTML = "";

    data.forEach(t => {
        const tr = document.createElement("tr");

        tr.innerHTML = `
            <td>${t.id}</td>
            <td>${t.derivativeId}</td>
            <td>${t.derivative?.underlying?.symbol ?? ""}</td>
            <td>${t.quantity}</td>
        `;

        tbody.appendChild(tr);
    });
}

async function evaluatePortfolio() {
    const body = {
        sims: parseInt(document.getElementById("sims").value),
        bump: parseFloat(document.getElementById("bump").value),
        antithetic: document.getElementById("antithetic").checked,
        controlVariate: document.getElementById("cv").checked,
        multithreading: document.getElementById("mt").checked
    };

    const res = await fetch(apiEval, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
    });

    const data = await res.json();

    document.getElementById("result").textContent = `
Total Market Value: ${data.totalMarketValue}
Delta: ${data.totalDelta}
Gamma: ${data.totalGamma}
Vega: ${data.totalVega}
Theta: ${data.totalTheta}
Rho: ${data.totalRho}
    `;
}

document.getElementById("eval-btn").addEventListener("click", evaluatePortfolio);

loadTrades();
