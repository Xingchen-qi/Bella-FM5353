namespace MCOptions.Api.DataTransfer
{
    public class AsianD : BaseOptD
    {
    }
}

