using Microsoft.AspNetCore.Mvc;
using MCOptions.Api.DataTransfer;
using MCOptions;

namespace MCOptions.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PricingC : ControllerBase
    {
        [HttpPost("euro")]
        public async Task<ActionResult<PriceRes>> PriceE([FromBody] EuroD req)
        {
            return await RunP(req, "euro", () => new EuroOpt { IsCall = req.IsCall });
        }

        [HttpPost("asian")]
        public async Task<ActionResult<PriceRes>> PriceA([FromBody] AsianD req)
        {
            return await RunP(req, "asian", () => new AsianOpt { IsCall = req.IsCall });
        }

        [HttpPost("digital")]
        public async Task<ActionResult<PriceRes>> PriceD([FromBody] DigitalD req)
        {
            return await RunP(req, "digital", () => new DigitOpt { IsCall = req.IsCall, Payout = req.Payout });
        }

        [HttpPost("barrier")]
        public async Task<ActionResult<PriceRes>> PriceB([FromBody] BarrierD req)
        {
            return await RunP(req, "barrier", () =>
            {
                var b = new BarrOpt { IsCall = req.IsCall, B = req.B };
                string k = (req.Knock ?? "do").Trim().ToLower();
                b.Knock = k switch
                {
                    "do" => KnockT.DO,
                    "uo" => KnockT.UO,
                    "di" => KnockT.DI,
                    "ui" => KnockT.UI,
                    _ => KnockT.DO
                };
                return b;
            });
        }

        [HttpPost("lookback")]
        public async Task<ActionResult<PriceRes>> PriceL([FromBody] LookbackD req)
        {
            return await RunP(req, "lookback", () => new LookOpt { IsCall = req.IsCall });
        }

        [HttpPost("range")]
        public async Task<ActionResult<PriceRes>> PriceR([FromBody] RangeD req)
        {
            return await RunP(req, "range", () => new RangeOpt());
        }

        private async Task<ActionResult<PriceRes>> RunP<TReq>(
            TReq req,
            string optType,
            Func<Opt> makeOpt) where TReq : BaseOptD
        {
            if (req.S0 <= 0 || req.K <= 0 || req.sig <= 0 || req.T <= 0 || req.N <= 0 || req.Sims <= 0)
                return BadRequest("Invalid input: S0, K, sig, T, N, and Sims must all be positive values.");

            var o = makeOpt();
            o.S0 = req.S0; o.K = req.K; o.r = req.r;
            o.sig = req.sig; o.T = req.T; o.N = req.N;

            var eng = new MCEngine(
                a: req.Engine?.Antithetic ?? false,
                c: req.Engine?.ControlVariate ?? false,
                m: req.Engine?.Multithreading ?? false
            );

            try
            {
                var r = await Task.Run(() => eng.Run(o, req.Sims, req.Bump));
                var dto = new PriceRes
                {
                    Price = r.Price, StdErr = r.StdErr, Delta = r.Delta,
                    Gamma = r.Gamma, Vega = r.Vega, Theta = r.Theta, Rho = r.Rho,
                    Sims = req.Sims, OptionType = optType,
                };
                return Ok(dto);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Server error: {ex.Message}");
            }
        }
    }
}
