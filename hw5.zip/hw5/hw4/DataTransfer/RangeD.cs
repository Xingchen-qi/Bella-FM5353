namespace MCOptions.Api.DataTransfer
{
    public class RangeD : BaseOptD
    {
    }
}
