namespace MCOptions.Api.DataTransfer
{
    public class EngineSwitchD
    {
        public bool Antithetic { get; set; } = false;
        public bool ControlVariate { get; set; } = false;
        public bool Multithreading { get; set; } = false;
    }

    public class BaseOptD
    {
        public double S0 { get; set; }
        public double K { get; set; }
        public double r { get; set; }
        public double sig { get; set; }
        public double T { get; set; }
        public int N { get; set; }
        public int Sims { get; set; }

        public bool IsCall { get; set; } = true;

        public EngineSwitchD Engine { get; set; } = new EngineSwitchD();

        public double Bump { get; set; } = 1e-3;
    }

    public class PriceRes
    {
        public double Price { get; set; }
        public double StdErr { get; set; }
        public double Delta { get; set; }
        public double Gamma { get; set; }
        public double Vega { get; set; }
        public double Theta { get; set; }
        public double Rho { get; set; }
        public int Sims { get; set; }
        public string OptionType { get; set; } = "";
        public object Echo { get; set; }
    }
}
