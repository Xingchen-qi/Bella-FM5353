namespace MCOptions.Api.DataTransfer
{
    public class DigitalD : BaseOptD
    {
        public double Payout { get; set; } = 1.0;
    }
}
